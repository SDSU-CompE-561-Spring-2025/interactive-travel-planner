import Title from "@/components/Title"
import Navbar from "@/components/Navbar";

<Navbar></Navbar>


export default function SignInPage () {
    return (
        <Title
            title="Sign In Page"
            subtitle="Please Sign In"
        />
    );
}
