import Title from "@/components/Title"



export default function contactUs () {
    return (
        <Title
            title="contact us"
            subtitle="contact us"
        />
    );
}
