import Title from "@/components/Title"
import Navbar from "@/components/Navbar";



export default function Jobs () {
    return (
        <Title
            title="jobs"
            subtitle="jobs"
        />
    );
}
