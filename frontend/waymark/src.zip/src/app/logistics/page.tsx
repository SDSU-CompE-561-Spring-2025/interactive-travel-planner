import Title from "@/components/Title"


export default function Logistics () {
    return (
        <Title
            title="logistics page"
            subtitle="how it works"
        />
    );
}
