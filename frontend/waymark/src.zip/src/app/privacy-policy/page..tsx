import Title from "@/components/Title"


export default function Privacy() {
    return (
        <Title
            title="privacy policy"
            subtitle="Privacy Policy"
        />
    );
}
