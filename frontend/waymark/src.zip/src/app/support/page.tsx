import Title from "@/components/Title";

export default function SupportPage() {
    return (
        <Title
            title="Support Page"
            subtitle="Please Contact Us"
        />
    );
}
